package com.example.ejercicioudp_sockets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.*;
import java.io.*;


public class MainActivity extends AppCompatActivity {

    private EditText editText1;
    private EditText edidText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = (EditText) findViewById(R.id.name_id_text);
        edidText2 = (EditText) findViewById(R.id.message_id_text);

    }


    public void enviar(View view) {
        String s1 = editText1.getText().toString();
        String s2 = edidText2.getText().toString();
        String sU = s1+":"+s2;
        client(sU);
    }

    public void client(String msg) {
        Toast toast1;
        try {
            DatagramSocket socketUDP = new DatagramSocket();
            byte[] mensaje = msg.getBytes();
            InetAddress hostServidor = InetAddress.getByName("192.168.1.130");
            int puertoServidor = 5555;

            // Construimos un datagrama para enviar el mensaje al servidor
            DatagramPacket peticion =
                    new DatagramPacket(mensaje, mensaje.length, hostServidor,
                            puertoServidor);


            // Enviamos el datagrama
            socketUDP.send(peticion);

            // Construimos el DatagramPacket que contendrá la respuesta
            byte[] bufer = new byte[1000];
            DatagramPacket respuesta =
                    new DatagramPacket(bufer, bufer.length);
            socketUDP.receive(respuesta);

            // Enviamos la respuesta del servidor a la salida estandar
            //System.out.println("Respuesta: " + new String(respuesta.getData()));
            toast1 =
                    Toast.makeText(getApplicationContext(),
                            "Respuesta: " + new String(respuesta.getData()), Toast.LENGTH_SHORT);

            toast1.show();

            // Cerramos el socket
            socketUDP.close();

        } catch (SocketException e) {
            //System.out.println("Socket: " + e.getMessage());
            toast1 =
                    Toast.makeText(getApplicationContext(),
                            "Socket: " + e.getMessage(), Toast.LENGTH_SHORT);

            toast1.show();


        } catch (IOException e) {
            //System.out.println("IO: " + e.getMessage());
            toast1 =
                    Toast.makeText(getApplicationContext(),
                            "IO: " + e.getMessage(), Toast.LENGTH_SHORT);

            toast1.show();

        }

    }
}


