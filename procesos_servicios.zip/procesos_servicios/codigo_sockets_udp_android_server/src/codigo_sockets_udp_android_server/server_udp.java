package codigo_sockets_udp_android_server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class server_udp {

    public static void main(String[] args) {
        try {
            DatagramSocket socketUDP = new DatagramSocket(5555);
            byte[] buffer = new byte[1000];
            String memoria = "";
            while (true) {
                
                DatagramPacket peticion = new DatagramPacket(buffer, buffer.length);
                socketUDP.receive(peticion);
                memoria += new String(peticion.getData())+"\n";
                String memoria_r = memoria.replaceAll("//s", "");
                DatagramPacket respuesta = new DatagramPacket(memoria_r.getBytes(), memoria_r.length(), peticion.getAddress(), peticion.getPort());
                
                System.out.println("mensaje: " + new String(memoria.getBytes()));
                socketUDP.send(respuesta);
            }
        } catch (SocketException e) {
            System.out.println("Socket: "+ e.getMessage());
        } catch(IOException e) {
            System.out.println("IO: " + e.getMessage());
        }
    }

}
