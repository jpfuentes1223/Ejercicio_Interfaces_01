package codigo_sockets_udp_android_server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class cliente_udp {

    public static void main(String args[]) {
        try {
            Scanner lector = new Scanner(System.in);
            System.out.println("Introduce nombre:");
            String name = lector.nextLine();
            System.out.println("Introduce mensaje");
            String message = lector.nextLine();
            
            DatagramSocket socketUDP = new DatagramSocket();
            byte[] mensaje = (name+":"+message).getBytes();
            InetAddress hostServidor = InetAddress.getByName("localhost");
            int puertoServidor = 5555;

            DatagramPacket peticion = new DatagramPacket(mensaje, mensaje.length, hostServidor, puertoServidor);

            socketUDP.send(peticion);

            byte[] buffer = new byte[1000];
            DatagramPacket respuesta = new DatagramPacket(buffer, buffer.length);
            socketUDP.receive(respuesta);

            System.out.println("Respuesta: " + new String(respuesta.getData()));
            System.out.println("Longitud repsuesta:  " + Integer.toString(respuesta.getLength()));

            socketUDP.close();
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        }
    }
}
