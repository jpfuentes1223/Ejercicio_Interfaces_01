package com.example.app_url_web;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebActivity extends AppCompatActivity {

    private WebView wv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        wv1 = (WebView)findViewById(R.id.webView01);
        String adreça = getIntent().getStringExtra("direcció");
        wv1.setWebViewClient(new WebViewClient());
        wv1.loadUrl(adreça);
    }

    public void cerrar(View v){
        finish();
    }
}