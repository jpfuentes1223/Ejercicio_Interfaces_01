package com.example.socketsudpandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.*;
import java.io.*;


public class MainActivity extends AppCompatActivity {

    private EditText editText1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1=(EditText)findViewById(R.id.editText1);

    }


    public void enviar(View view){
        String s1=editText1.getText().toString();
        client(s1);
    }

    public void client(String msg){
        Toast toast1;
        try {
            DatagramSocket socketUDP = new DatagramSocket();
            byte[] mensaje = msg.getBytes();
            InetAddress hostServidor = InetAddress.getByName("192.168.135.52");
            int puertoServidor = 5559;

            // Construimos un datagrama para enviar el mensaje al servidor
            DatagramPacket peticion =
                    new DatagramPacket(mensaje, mensaje.length, hostServidor,
                            puertoServidor);


            // Enviamos el datagrama
            socketUDP.send(peticion);

            // Construimos el DatagramPacket que contendrá la respuesta
            byte[] bufer = new byte[1000];
            DatagramPacket respuesta =
                    new DatagramPacket(bufer, bufer.length);
            socketUDP.receive(respuesta);

            // Enviamos la respuesta del servidor a la salida estandar
            //System.out.println("Respuesta: " + new String(respuesta.getData()));
            toast1 =
                    Toast.makeText(getApplicationContext(),
                            "Respuesta: " + new String(respuesta.getData()) , Toast.LENGTH_SHORT);

            toast1.show();

            // Cerramos el socket
            socketUDP.close();

        } catch (SocketException e) {
            //System.out.println("Socket: " + e.getMessage());
            toast1 =
                    Toast.makeText(getApplicationContext(),
                            "Socket: "+e.getMessage() , Toast.LENGTH_SHORT);

            toast1.show();


        } catch (IOException e) {
            //System.out.println("IO: " + e.getMessage());
            toast1 =
                    Toast.makeText(getApplicationContext(),
                            "IO: "+e.getMessage() , Toast.LENGTH_SHORT);

            toast1.show();

        }

    }
}

